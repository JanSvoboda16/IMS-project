
Reference results for SIMLIB/C++ examples
=========================================

You should get the same results in 64bit environment.

64bit version uses SSE instructions with slightly less accuracy of computation
- some tiny rounding differences are expected in 32bit vs. 64bit comparison.

TODO: use fenv to set rounding etc.
      or try to print resuts with less accuracy to mask rounding errors
      use english names and comments (partially done)
      re-add some example of correct WaitUntil usage

